-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           8.0.25 - MySQL Community Server - GPL
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.0.0.6468
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Copiando estrutura para tabela estacionamentojn.car
CREATE TABLE IF NOT EXISTS `car` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `dirImage` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `car_name_unique` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

-- Copiando dados para a tabela estacionamentojn.car: ~69 rows (aproximadamente)
REPLACE INTO `car` (`id`, `name`, `created_at`, `updated_at`, `dirImage`, `type`) VALUES
	(25, 'Entrada car1689001454859', '2023-07-10 15:04:14', '2023-07-10 15:04:14', 'uploads/car/car1689001454859.jpg', 'Entrada '),
	(26, 'Entrada car1689001546626', '2023-07-10 15:05:46', '2023-07-10 15:05:46', 'uploads/car/car1689001546626.jpg', 'Entrada '),
	(27, 'Entrada car1689001550814', '2023-07-10 15:05:50', '2023-07-10 15:05:50', 'uploads/car/car1689001550814.jpg', 'Entrada '),
	(28, 'Entrada car1689005247323', '2023-07-10 16:07:27', '2023-07-10 16:07:27', 'uploads/car/car1689005247323.jpg', 'Entrada '),
	(29, 'Entrada car1689005267428', '2023-07-10 16:07:47', '2023-07-10 16:07:47', 'uploads/car/car1689005267428.jpg', 'Entrada '),
	(30, 'Entrada car1689005558612', '2023-07-10 16:12:38', '2023-07-10 16:12:38', 'uploads/car/car1689005558612.jpg', 'Entrada '),
	(31, 'Entrada car1689005570699', '2023-07-10 16:12:50', '2023-07-10 16:12:50', 'uploads/car/car1689005570699.jpg', 'Entrada '),
	(32, 'Entrada car1689005592915', '2023-07-10 16:13:12', '2023-07-10 16:13:12', 'uploads/car/car1689005592915.jpg', 'Entrada '),
	(33, 'Entrada car1689030013789', '2023-07-10 23:00:13', '2023-07-10 23:00:13', 'uploads/car/car1689030013789.jpg', 'Entrada '),
	(34, 'Entrada car1689030093500', '2023-07-10 23:01:33', '2023-07-10 23:01:33', 'uploads/car/car1689030093500.jpg', 'Entrada '),
	(35, 'Entrada car1689034578520', '2023-07-11 00:16:18', '2023-07-11 00:16:18', 'uploads/car/car1689034578520.jpg', 'Entrada '),
	(36, 'Entrada car1689036715975', '2023-07-11 00:51:55', '2023-07-11 00:51:55', 'uploads/car/car1689036715975.jpg', 'Entrada '),
	(37, 'Entrada car1689036718140', '2023-07-11 00:51:58', '2023-07-11 00:51:58', 'uploads/car/car1689036718140.jpg', 'Entrada '),
	(38, 'Entrada car1689119510274', '2023-07-11 23:51:50', '2023-07-11 23:51:50', 'uploads/car/car1689119510274.jpg', 'Entrada '),
	(39, 'Entrada car1689204045650', '2023-07-12 23:20:45', '2023-07-12 23:20:45', 'uploads/car/car1689204045650.jpg', 'Entrada '),
	(40, 'Entrada car1689209561318', '2023-07-13 00:52:41', '2023-07-13 00:52:41', 'uploads/car/car1689209561318.jpg', 'Entrada '),
	(41, 'Entrada car1689209562976', '2023-07-13 00:52:42', '2023-07-13 00:52:42', 'uploads/car/car1689209562976.jpg', 'Entrada '),
	(42, 'Entrada car1689209579137', '2023-07-13 00:52:59', '2023-07-13 00:52:59', 'uploads/car/car1689209579137.jpg', 'Entrada '),
	(43, 'Entrada car1689209581172', '2023-07-13 00:53:01', '2023-07-13 00:53:01', 'uploads/car/car1689209581172.jpg', 'Entrada '),
	(44, 'Entrada car1689264913719', '2023-07-13 16:15:13', '2023-07-13 16:15:13', 'uploads/car/car1689264913719.jpg', 'Entrada '),
	(45, 'Entrada car1689265088840', '2023-07-13 16:18:08', '2023-07-13 16:18:08', 'uploads/car/car1689265088840.jpg', 'Entrada '),
	(46, 'Entrada car1689265196115', '2023-07-13 16:19:56', '2023-07-13 16:19:56', 'uploads/car/car1689265196115.jpg', 'Entrada '),
	(47, 'Entrada car1689265201814', '2023-07-13 16:20:01', '2023-07-13 16:20:01', 'uploads/car/car1689265201814.jpg', 'Entrada '),
	(48, 'Entrada car1689265209451', '2023-07-13 16:20:09', '2023-07-13 16:20:09', 'uploads/car/car1689265209451.jpg', 'Entrada '),
	(49, 'Entrada car1689266351185', '2023-07-13 16:39:11', '2023-07-13 16:39:11', 'uploads/car/car1689266351185.jpg', 'Entrada '),
	(50, 'Entrada car1689363746585', '2023-07-14 19:42:26', '2023-07-14 19:42:26', 'uploads/car/car1689363746585.jpg', 'Entrada '),
	(51, 'Entrada car1689364137240', '2023-07-14 19:48:57', '2023-07-14 19:48:57', 'uploads/car/car1689364137240.jpg', 'Entrada '),
	(52, 'Entrada car1689364647405', '2023-07-14 19:57:27', '2023-07-14 19:57:27', 'uploads/car/car1689364647405.jpg', 'Entrada '),
	(53, 'Entrada car1689364652126', '2023-07-14 19:57:32', '2023-07-14 19:57:32', 'uploads/car/car1689364652126.jpg', 'Entrada '),
	(54, 'Entrada car1689364770508', '2023-07-14 19:59:30', '2023-07-14 19:59:30', 'uploads/car/car1689364770508.jpg', 'Entrada '),
	(55, 'Entrada car1689364773254', '2023-07-14 19:59:33', '2023-07-14 19:59:33', 'uploads/car/car1689364773254.jpg', 'Entrada '),
	(56, 'Entrada car1689364779277', '2023-07-14 19:59:39', '2023-07-14 19:59:39', 'uploads/car/car1689364779277.jpg', 'Entrada '),
	(57, 'Entrada car1689364909439', '2023-07-14 20:01:49', '2023-07-14 20:01:49', 'uploads/car/car1689364909439.jpg', 'Entrada '),
	(58, 'Entrada car1689364946715', '2023-07-14 20:02:26', '2023-07-14 20:02:26', 'uploads/car/car1689364946715.jpg', 'Entrada '),
	(59, 'Entrada car1689365129984', '2023-07-14 20:05:29', '2023-07-14 20:05:29', 'uploads/car/car1689365129984.jpg', 'Entrada '),
	(60, 'Entrada car1689365597972', '2023-07-14 20:13:17', '2023-07-14 20:13:17', 'uploads/car/car1689365597972.jpg', 'Entrada '),
	(61, 'Entrada car1689372965751', '2023-07-14 22:16:05', '2023-07-14 22:16:05', 'uploads/car/car1689372965751.jpg', 'Entrada '),
	(62, 'Entrada car1689372968436', '2023-07-14 22:16:08', '2023-07-14 22:16:08', 'uploads/car/car1689372968436.jpg', 'Entrada '),
	(63, 'Entrada car1689372971952', '2023-07-14 22:16:11', '2023-07-14 22:16:11', 'uploads/car/car1689372971952.jpg', 'Entrada '),
	(64, 'Entrada car1689372987891', '2023-07-14 22:16:27', '2023-07-14 22:16:27', 'uploads/car/car1689372987891.jpg', 'Entrada '),
	(65, 'Entrada car1689373364513', '2023-07-14 22:22:44', '2023-07-14 22:22:44', 'uploads/car/car1689373364513.jpg', 'Entrada '),
	(66, 'Entrada car1689373730512', '2023-07-14 22:28:50', '2023-07-14 22:28:50', 'uploads/car/car1689373730512.jpg', 'Entrada '),
	(67, 'Entrada car1689374234240', '2023-07-14 22:37:14', '2023-07-14 22:37:14', 'uploads/car/car1689374234240.jpg', 'Entrada '),
	(68, 'Entrada car1689375914216', '2023-07-14 23:05:14', '2023-07-14 23:05:14', 'uploads/car/car1689375914216.jpg', 'Entrada '),
	(69, 'Entrada car1689375918939', '2023-07-14 23:05:18', '2023-07-14 23:05:18', 'uploads/car/car1689375918939.jpg', 'Entrada '),
	(70, 'Entrada car1689375925797', '2023-07-14 23:05:25', '2023-07-14 23:05:25', 'uploads/car/car1689375925797.jpg', 'Entrada '),
	(71, 'Entrada car1689375928020', '2023-07-14 23:05:28', '2023-07-14 23:05:28', 'uploads/car/car1689375928020.jpg', 'Entrada '),
	(72, 'Entrada car1689375931424', '2023-07-14 23:05:31', '2023-07-14 23:05:31', 'uploads/car/car1689375931424.jpg', 'Entrada '),
	(73, 'Entrada car1689375933280', '2023-07-14 23:05:33', '2023-07-14 23:05:33', 'uploads/car/car1689375933280.jpg', 'Entrada '),
	(74, 'Entrada car1689375940167', '2023-07-14 23:05:40', '2023-07-14 23:05:40', 'uploads/car/car1689375940167.jpg', 'Entrada '),
	(75, 'Entrada car1689375942582', '2023-07-14 23:05:42', '2023-07-14 23:05:42', 'uploads/car/car1689375942582.jpg', 'Entrada '),
	(76, 'Entrada car1689375950648', '2023-07-14 23:05:50', '2023-07-14 23:05:50', 'uploads/car/car1689375950648.jpg', 'Entrada '),
	(77, 'Entrada car1689375968098', '2023-07-14 23:06:08', '2023-07-14 23:06:08', 'uploads/car/car1689375968098.jpg', 'Entrada '),
	(78, 'Entrada car1689375976618', '2023-07-14 23:06:16', '2023-07-14 23:06:16', 'uploads/car/car1689375976618.jpg', 'Entrada '),
	(79, 'Entrada car1689375978586', '2023-07-14 23:06:18', '2023-07-14 23:06:18', 'uploads/car/car1689375978586.jpg', 'Entrada '),
	(80, 'Entrada car1689375982088', '2023-07-14 23:06:22', '2023-07-14 23:06:22', 'uploads/car/car1689375982088.jpg', 'Entrada '),
	(81, 'Entrada car1689376001710', '2023-07-14 23:06:41', '2023-07-14 23:06:41', 'uploads/car/car1689376001710.jpg', 'Entrada '),
	(82, 'Entrada car1689377948601', '2023-07-14 23:39:08', '2023-07-14 23:39:08', 'uploads/car/car1689377948601.jpg', 'Entrada '),
	(83, 'Entrada car1689377950329', '2023-07-14 23:39:10', '2023-07-14 23:39:10', 'uploads/car/car1689377950329.jpg', 'Entrada '),
	(84, 'Entrada car1689377951801', '2023-07-14 23:39:11', '2023-07-14 23:39:11', 'uploads/car/car1689377951801.jpg', 'Entrada '),
	(85, 'Entrada car1689377953642', '2023-07-14 23:39:13', '2023-07-14 23:39:13', 'uploads/car/car1689377953642.jpg', 'Entrada '),
	(86, 'Entrada car1689377954968', '2023-07-14 23:39:14', '2023-07-14 23:39:14', 'uploads/car/car1689377954968.jpg', 'Entrada '),
	(87, 'Entrada car1689377957154', '2023-07-14 23:39:17', '2023-07-14 23:39:17', 'uploads/car/car1689377957154.jpg', 'Entrada '),
	(88, 'Entrada car1689377960510', '2023-07-14 23:39:20', '2023-07-14 23:39:20', 'uploads/car/car1689377960510.jpg', 'Entrada '),
	(89, 'Entrada car1689377963565', '2023-07-14 23:39:23', '2023-07-14 23:39:23', 'uploads/car/car1689377963565.jpg', 'Entrada '),
	(90, 'Entrada car1689377965150', '2023-07-14 23:39:25', '2023-07-14 23:39:25', 'uploads/car/car1689377965150.jpg', 'Entrada '),
	(91, 'Entrada car1689377968581', '2023-07-14 23:39:28', '2023-07-14 23:39:28', 'uploads/car/car1689377968581.jpg', 'Entrada '),
	(92, 'Entrada car1689377981796', '2023-07-14 23:39:41', '2023-07-14 23:39:41', 'uploads/car/car1689377981796.jpg', 'Entrada '),
	(93, 'Entrada car1689378033554', '2023-07-14 23:40:33', '2023-07-14 23:40:33', 'uploads/car/car1689378033554.jpg', 'Entrada ');

-- Copiando estrutura para tabela estacionamentojn.fot
CREATE TABLE IF NOT EXISTS `fot` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `dirImage` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `car_name_unique` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

-- Copiando dados para a tabela estacionamentojn.fot: ~107 rows (aproximadamente)
REPLACE INTO `fot` (`id`, `name`, `created_at`, `updated_at`, `dirImage`, `type`) VALUES
	(1, 'Entrada car1689378862860', '2023-07-14 23:54:22', '2023-07-14 23:54:22', 'uploads/car/car1689378862860.jpg', 'Entrada '),
	(2, 'Entrada car1689378866531', '2023-07-14 23:54:26', '2023-07-14 23:54:26', 'uploads/car/car1689378866531.jpg', 'Entrada '),
	(3, 'Entrada car1689455322959', '2023-07-15 21:08:42', '2023-07-15 21:08:42', 'uploads/car/car1689455322959.jpg', 'Entrada '),
	(4, 'Entrada car1689455351120', '2023-07-15 21:09:11', '2023-07-15 21:09:11', 'uploads/car/car1689455351120.jpg', 'Entrada '),
	(5, 'Entrada car1689455435086', '2023-07-15 21:10:35', '2023-07-15 21:10:35', 'uploads/car/car1689455435086.jpg', 'Entrada '),
	(6, 'Entrada car1689455455225', '2023-07-15 21:10:55', '2023-07-15 21:10:55', 'uploads/car/car1689455455225.jpg', 'Entrada '),
	(7, 'Entrada car1689455481792', '2023-07-15 21:11:21', '2023-07-15 21:11:21', 'uploads/car/car1689455481792.jpg', 'Entrada '),
	(8, 'Entrada car1689455603274', '2023-07-15 21:13:23', '2023-07-15 21:13:23', 'uploads/car/car1689455603274.jpg', 'Entrada '),
	(9, 'Entrada car1689455613693', '2023-07-15 21:13:33', '2023-07-15 21:13:33', 'uploads/car/car1689455613693.jpg', 'Entrada '),
	(10, 'Entrada car1689455644807', '2023-07-15 21:14:04', '2023-07-15 21:14:04', 'uploads/car/car1689455644807.jpg', 'Entrada '),
	(11, 'Entrada car1689455649383', '2023-07-15 21:14:09', '2023-07-15 21:14:09', 'uploads/car/car1689455649383.jpg', 'Entrada '),
	(12, 'Entrada car1689455654708', '2023-07-15 21:14:14', '2023-07-15 21:14:14', 'uploads/car/car1689455654708.jpg', 'Entrada '),
	(13, 'Entrada car1689455658938', '2023-07-15 21:14:18', '2023-07-15 21:14:18', 'uploads/car/car1689455658938.jpg', 'Entrada '),
	(14, 'Entrada car1689455665284', '2023-07-15 21:14:25', '2023-07-15 21:14:25', 'uploads/car/car1689455665284.jpg', 'Entrada '),
	(15, 'Entrada car1689461801730', '2023-07-15 22:56:41', '2023-07-15 22:56:41', 'uploads/car/car1689461801730.jpg', 'Entrada '),
	(16, 'Entrada car1689461918619', '2023-07-15 22:58:38', '2023-07-15 22:58:38', 'uploads/car/car1689461918619.jpg', 'Entrada '),
	(17, 'Entrada car1689461947521', '2023-07-15 22:59:07', '2023-07-15 22:59:07', 'uploads/car/car1689461947521.jpg', 'Entrada '),
	(18, 'Entrada car1689461952225', '2023-07-15 22:59:12', '2023-07-15 22:59:12', 'uploads/car/car1689461952225.jpg', 'Entrada '),
	(19, 'Entrada car1689462033880', '2023-07-15 23:00:33', '2023-07-15 23:00:33', 'uploads/car/car1689462033880.jpg', 'Entrada '),
	(20, 'Entrada car1689462046806', '2023-07-15 23:00:46', '2023-07-15 23:00:46', 'uploads/car/car1689462046806.jpg', 'Entrada '),
	(21, 'Entrada car1689462071204', '2023-07-15 23:01:11', '2023-07-15 23:01:11', 'uploads/car/car1689462071204.jpg', 'Entrada '),
	(22, 'Entrada car1689521088803', '2023-07-16 15:24:48', '2023-07-16 15:24:48', 'uploads/car/car1689521088803.jpg', 'Entrada '),
	(23, 'Entrada car1689521095161', '2023-07-16 15:24:55', '2023-07-16 15:24:55', 'uploads/car/car1689521095161.jpg', 'Entrada '),
	(24, 'Entrada car1689521104945', '2023-07-16 15:25:04', '2023-07-16 15:25:04', 'uploads/car/car1689521104945.jpg', 'Entrada '),
	(25, 'Entrada car1689521105351', '2023-07-16 15:25:05', '2023-07-16 15:25:05', 'uploads/car/car1689521105351.jpg', 'Entrada '),
	(26, 'Entrada car1689521109014', '2023-07-16 15:25:09', '2023-07-16 15:25:09', 'uploads/car/car1689521109014.jpg', 'Entrada '),
	(27, 'Entrada car1689521274663', '2023-07-16 15:27:54', '2023-07-16 15:27:54', 'uploads/car/car1689521274663.jpg', 'Entrada '),
	(28, 'Entrada car1689521573531', '2023-07-16 15:32:53', '2023-07-16 15:32:53', 'uploads/car/car1689521573531.jpg', 'Entrada '),
	(29, 'Entrada car1689521575878', '2023-07-16 15:32:55', '2023-07-16 15:32:55', 'uploads/car/car1689521575878.jpg', 'Entrada '),
	(30, 'Entrada car1689521579415', '2023-07-16 15:32:59', '2023-07-16 15:32:59', 'uploads/car/car1689521579415.jpg', 'Entrada '),
	(31, 'Entrada car1689521647867', '2023-07-16 15:34:07', '2023-07-16 15:34:07', 'uploads/car/car1689521647867.jpg', 'Entrada '),
	(32, 'Entrada car1689521655187', '2023-07-16 15:34:15', '2023-07-16 15:34:15', 'uploads/car/car1689521655187.jpg', 'Entrada '),
	(33, 'Entrada car1689521663125', '2023-07-16 15:34:23', '2023-07-16 15:34:23', 'uploads/car/car1689521663125.jpg', 'Entrada '),
	(34, 'Entrada car1689521668708', '2023-07-16 15:34:28', '2023-07-16 15:34:28', 'uploads/car/car1689521668708.jpg', 'Entrada '),
	(35, 'Entrada car1689521970931', '2023-07-16 15:39:30', '2023-07-16 15:39:30', 'uploads/car/car1689521970931.jpg', 'Entrada '),
	(36, 'Entrada car1689522019375', '2023-07-16 15:40:19', '2023-07-16 15:40:19', 'uploads/car/car1689522019375.jpg', 'Entrada '),
	(37, 'Entrada car1689522068756', '2023-07-16 15:41:08', '2023-07-16 15:41:08', 'uploads/car/car1689522068756.jpg', 'Entrada '),
	(38, 'Entrada car1689522072024', '2023-07-16 15:41:12', '2023-07-16 15:41:12', 'uploads/car/car1689522072024.jpg', 'Entrada '),
	(39, 'Entrada car1689522075602', '2023-07-16 15:41:15', '2023-07-16 15:41:15', 'uploads/car/car1689522075602.jpg', 'Entrada '),
	(40, 'Entrada car1689522077715', '2023-07-16 15:41:17', '2023-07-16 15:41:17', 'uploads/car/car1689522077715.jpg', 'Entrada '),
	(41, 'Entrada car1689522079591', '2023-07-16 15:41:19', '2023-07-16 15:41:19', 'uploads/car/car1689522079591.jpg', 'Entrada '),
	(42, 'Entrada car1689522081000', '2023-07-16 15:41:21', '2023-07-16 15:41:21', 'uploads/car/car1689522081000.jpg', 'Entrada '),
	(43, 'Entrada car1689524347044', '2023-07-16 16:19:07', '2023-07-16 16:19:07', 'uploads/car/car1689524347044.jpg', 'Entrada '),
	(44, 'Entrada car1689524347663', '2023-07-16 16:19:07', '2023-07-16 16:19:07', 'uploads/car/car1689524347663.jpg', 'Entrada '),
	(45, 'Entrada car1689524348227', '2023-07-16 16:19:08', '2023-07-16 16:19:08', 'uploads/car/car1689524348227.jpg', 'Entrada '),
	(46, 'Entrada car1689524806089', '2023-07-16 16:26:46', '2023-07-16 16:26:46', 'uploads/car/car1689524806089.jpg', 'Entrada '),
	(47, 'Entrada car1689525103478', '2023-07-16 16:31:43', '2023-07-16 16:31:43', 'uploads/car/car1689525103478.jpg', 'Entrada '),
	(48, 'Entrada car1689525111037', '2023-07-16 16:31:51', '2023-07-16 16:31:51', 'uploads/car/car1689525111037.jpg', 'Entrada '),
	(49, 'Entrada car1689525133156', '2023-07-16 16:32:13', '2023-07-16 16:32:13', 'uploads/car/car1689525133156.jpg', 'Entrada '),
	(50, 'Entrada car1689525133720', '2023-07-16 16:32:13', '2023-07-16 16:32:13', 'uploads/car/car1689525133720.jpg', 'Entrada '),
	(51, 'Entrada car1689525134392', '2023-07-16 16:32:14', '2023-07-16 16:32:14', 'uploads/car/car1689525134392.jpg', 'Entrada '),
	(52, 'Entrada car1689525165312', '2023-07-16 16:32:45', '2023-07-16 16:32:45', 'uploads/car/car1689525165312.jpg', 'Entrada '),
	(53, 'Entrada car1689525677446', '2023-07-16 16:41:17', '2023-07-16 16:41:17', 'uploads/car/car1689525677446.jpg', 'Entrada '),
	(54, 'Entrada car1689525808148', '2023-07-16 16:43:28', '2023-07-16 16:43:28', 'uploads/car/car1689525808148.jpg', 'Entrada '),
	(55, 'Entrada car1689525850080', '2023-07-16 16:44:10', '2023-07-16 16:44:10', 'uploads/car/car1689525850080.jpg', 'Entrada '),
	(56, 'Entrada car1689525856207', '2023-07-16 16:44:16', '2023-07-16 16:44:16', 'uploads/car/car1689525856207.jpg', 'Entrada '),
	(57, 'Entrada car1689525857214', '2023-07-16 16:44:17', '2023-07-16 16:44:17', 'uploads/car/car1689525857214.jpg', 'Entrada '),
	(58, 'Entrada car1689525857974', '2023-07-16 16:44:17', '2023-07-16 16:44:17', 'uploads/car/car1689525857974.jpg', 'Entrada '),
	(59, 'Entrada car1689525858783', '2023-07-16 16:44:18', '2023-07-16 16:44:18', 'uploads/car/car1689525858783.jpg', 'Entrada '),
	(60, 'Entrada car1689525940383', '2023-07-16 16:45:40', '2023-07-16 16:45:40', 'uploads/car/car1689525940383.jpg', 'Entrada '),
	(61, 'Entrada car1689525949203', '2023-07-16 16:45:49', '2023-07-16 16:45:49', 'uploads/car/car1689525949203.jpg', 'Entrada '),
	(62, 'Entrada car1689525956882', '2023-07-16 16:45:56', '2023-07-16 16:45:56', 'uploads/car/car1689525956882.jpg', 'Entrada '),
	(63, 'Entrada car1689525961911', '2023-07-16 16:46:01', '2023-07-16 16:46:01', 'uploads/car/car1689525961911.jpg', 'Entrada '),
	(64, 'Entrada car1689526003045', '2023-07-16 16:46:43', '2023-07-16 16:46:43', 'uploads/car/car1689526003045.jpg', 'Entrada '),
	(65, 'Entrada car1689526007240', '2023-07-16 16:46:47', '2023-07-16 16:46:47', 'uploads/car/car1689526007240.jpg', 'Entrada '),
	(66, 'Entrada car1689526190362', '2023-07-16 16:49:50', '2023-07-16 16:49:50', 'uploads/car/car1689526190362.jpg', 'Entrada '),
	(67, 'Entrada car1689526206365', '2023-07-16 16:50:06', '2023-07-16 16:50:06', 'uploads/car/car1689526206365.jpg', 'Entrada '),
	(68, 'Entrada car1689526210442', '2023-07-16 16:50:10', '2023-07-16 16:50:10', 'uploads/car/car1689526210442.jpg', 'Entrada '),
	(69, 'Entrada car1689526220461', '2023-07-16 16:50:20', '2023-07-16 16:50:20', 'uploads/car/car1689526220461.jpg', 'Entrada '),
	(70, 'Entrada car1689526224951', '2023-07-16 16:50:24', '2023-07-16 16:50:24', 'uploads/car/car1689526224951.jpg', 'Entrada '),
	(71, 'Entrada car1689526232852', '2023-07-16 16:50:32', '2023-07-16 16:50:32', 'uploads/car/car1689526232852.jpg', 'Entrada '),
	(72, 'Entrada car1689526233756', '2023-07-16 16:50:33', '2023-07-16 16:50:33', 'uploads/car/car1689526233756.jpg', 'Entrada '),
	(73, 'Entrada car1689526237153', '2023-07-16 16:50:37', '2023-07-16 16:50:37', 'uploads/car/car1689526237153.jpg', 'Entrada '),
	(74, 'Entrada car1689544436576', '2023-07-16 21:53:56', '2023-07-16 21:53:56', 'uploads/car/car1689544436576.jpg', 'Entrada '),
	(75, 'Entrada car1689544441477', '2023-07-16 21:54:01', '2023-07-16 21:54:01', 'uploads/car/car1689544441477.jpg', 'Entrada '),
	(76, 'Entrada car1689544446157', '2023-07-16 21:54:06', '2023-07-16 21:54:06', 'uploads/car/car1689544446157.jpg', 'Entrada '),
	(77, 'Entrada car1689544446734', '2023-07-16 21:54:06', '2023-07-16 21:54:06', 'uploads/car/car1689544446734.jpg', 'Entrada '),
	(78, 'Entrada car1689544449295', '2023-07-16 21:54:09', '2023-07-16 21:54:09', 'uploads/car/car1689544449295.jpg', 'Entrada '),
	(79, 'Entrada car1689544449568', '2023-07-16 21:54:09', '2023-07-16 21:54:09', 'uploads/car/car1689544449568.jpg', 'Entrada '),
	(80, 'Entrada car1689544449937', '2023-07-16 21:54:09', '2023-07-16 21:54:09', 'uploads/car/car1689544449937.jpg', 'Entrada '),
	(81, 'Entrada car1689544452742', '2023-07-16 21:54:12', '2023-07-16 21:54:12', 'uploads/car/car1689544452742.jpg', 'Entrada '),
	(82, 'Entrada car1689544453698', '2023-07-16 21:54:13', '2023-07-16 21:54:13', 'uploads/car/car1689544453698.jpg', 'Entrada '),
	(83, 'Entrada car1689544543278', '2023-07-16 21:55:43', '2023-07-16 21:55:43', 'uploads/car/car1689544543278.jpg', 'Entrada '),
	(84, 'Entrada car1689544550366', '2023-07-16 21:55:50', '2023-07-16 21:55:50', 'uploads/car/car1689544550366.jpg', 'Entrada '),
	(85, 'Entrada car1689544554585', '2023-07-16 21:55:54', '2023-07-16 21:55:54', 'uploads/car/car1689544554585.jpg', 'Entrada '),
	(86, 'Entrada car1689544579355', '2023-07-16 21:56:19', '2023-07-16 21:56:19', 'uploads/car/car1689544579355.jpg', 'Entrada '),
	(87, 'Entrada car1689544588419', '2023-07-16 21:56:28', '2023-07-16 21:56:28', 'uploads/car/car1689544588419.jpg', 'Entrada '),
	(88, 'Entrada car1689544632475', '2023-07-16 21:57:12', '2023-07-16 21:57:12', 'uploads/car/car1689544632475.jpg', 'Entrada '),
	(89, 'Entrada car1689544634049', '2023-07-16 21:57:14', '2023-07-16 21:57:14', 'uploads/car/car1689544634049.jpg', 'Entrada '),
	(90, 'Entrada car1689544636761', '2023-07-16 21:57:16', '2023-07-16 21:57:16', 'uploads/car/car1689544636761.jpg', 'Entrada '),
	(91, 'Entrada car1689633743910', '2023-07-17 22:42:23', '2023-07-17 22:42:23', 'uploads/car/car1689633743910.jpg', 'Entrada '),
	(92, 'Entrada car1689634149824', '2023-07-17 22:49:09', '2023-07-17 22:49:09', 'uploads/car/car1689634149824.jpg', 'Entrada '),
	(93, 'Entrada car1689709099009', '2023-07-18 19:38:19', '2023-07-18 19:38:19', 'uploads/car/car1689709099009.jpg', 'Entrada '),
	(94, 'Entrada car1689709141829', '2023-07-18 19:39:01', '2023-07-18 19:39:01', 'uploads/car/car1689709141829.jpg', 'Entrada '),
	(95, 'Entrada car1689709151821', '2023-07-18 19:39:11', '2023-07-18 19:39:11', 'uploads/car/car1689709151821.jpg', 'Entrada '),
	(96, 'Entrada car1689709175465', '2023-07-18 19:39:35', '2023-07-18 19:39:35', 'uploads/car/car1689709175465.jpg', 'Entrada '),
	(97, 'Entrada car1689709247989', '2023-07-18 19:40:47', '2023-07-18 19:40:47', 'uploads/car/car1689709247989.jpg', 'Entrada '),
	(98, 'Entrada car1689727171665', '2023-07-19 00:39:31', '2023-07-19 00:39:31', 'uploads/car/car1689727171665.jpg', 'Entrada '),
	(99, 'Entrada car1689727174474', '2023-07-19 00:39:34', '2023-07-19 00:39:34', 'uploads/car/car1689727174474.jpg', 'Entrada '),
	(100, 'Entrada car1689727175775', '2023-07-19 00:39:35', '2023-07-19 00:39:35', 'uploads/car/car1689727175775.jpg', 'Entrada '),
	(101, 'Entrada car1689727180201', '2023-07-19 00:39:40', '2023-07-19 00:39:40', 'uploads/car/car1689727180201.jpg', 'Entrada '),
	(102, 'Entrada car1689727184879', '2023-07-19 00:39:44', '2023-07-19 00:39:44', 'uploads/car/car1689727184879.jpg', 'Entrada '),
	(103, 'Entrada car1689727191147', '2023-07-19 00:39:51', '2023-07-19 00:39:51', 'uploads/car/car1689727191147.jpg', 'Entrada '),
	(104, 'Entrada car1689727191189', '2023-07-19 00:39:51', '2023-07-19 00:39:51', 'uploads/car/car1689727191189.jpg', 'Entrada '),
	(105, 'Entrada car1689805897841', '2023-07-19 22:31:37', '2023-07-19 22:31:37', 'uploads/car/car1689805897841.jpg', 'Entrada '),
	(106, 'Entrada car1689807228638', '2023-07-19 22:53:48', '2023-07-19 22:53:48', 'uploads/car/car1689807228638.jpg', 'Entrada '),
	(107, 'Entrada car1689807443145', '2023-07-19 22:57:23', '2023-07-19 22:57:23', 'uploads/car/car1689807443145.jpg', 'Entrada ');

-- Copiando estrutura para tabela estacionamentojn.sessions
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int unsigned NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Copiando dados para a tabela estacionamentojn.sessions: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela estacionamentojn.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `user` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `pass` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `rol` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `username_UNIQUE` (`user`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

-- Copiando dados para a tabela estacionamentojn.users: ~2 rows (aproximadamente)
REPLACE INTO `users` (`id`, `name`, `user`, `pass`, `email`, `rol`) VALUES
	(1, '', 'admin', '$2a$06$HT.EmXYUUhNo3UQMl9APmeC0SwoGsx7FtMoAWdzGicZJ4wR1J8alW', 'ocelio.bernardo@gmail.com', 'admin'),
	(5, 'celio', 'celiolima', '$2a$08$rwyXsP9Ea/w.Fz1ENICYteLsAT0MHDxLKEZx3oFt6uq2MFJ6c0mrG', '', 'user');

-- Copiando estrutura para tabela estacionamentojn.veic
CREATE TABLE IF NOT EXISTS `veic` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `total_car_mes` int unsigned DEFAULT NULL,
  `total_car` int unsigned DEFAULT NULL,
  `total_mot_mes` int unsigned DEFAULT NULL,
  `total_mot` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

-- Copiando dados para a tabela estacionamentojn.veic: ~1 rows (aproximadamente)
REPLACE INTO `veic` (`id`, `total_car_mes`, `total_car`, `total_mot_mes`, `total_mot`, `created_at`) VALUES
	(1, 9, 11, 10, 13, '2023-07-16 22:17:29');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
